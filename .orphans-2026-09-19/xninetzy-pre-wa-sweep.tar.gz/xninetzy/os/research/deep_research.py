from __future__ import annotations

import asyncio
import re

from xninetzy.core.config import get_settings
from xninetzy.interfaces.api.chat_events import emit_chat_event
from xninetzy.os.notifications.admin_notifier import notify_admin
from xninetzy.os.research.actions.base import ResearchActionInput
from xninetzy.os.research.actions.registry import ResearchActionRegistry
from xninetzy.os.research.citations import format_sources_block, validate_citations
from xninetzy.os.research.guards import check_resource_guards, resource_guard_denied_message
from xninetzy.os.research.permissions import can_run_deep_research, deep_research_denied_message
from xninetzy.os.research.session import (
    add_sources,
    add_substep,
    create_research_session,
    fail_session,
    finish_session,
    list_research_sessions,
    set_plan,
    update_substep_status,
)
from xninetzy.os.research.sources import assign_sids
from xninetzy.os.research.subplanner import ResearchSubPlan


MODE_LIMITS = {
    "speed": {"selected": 5, "query_limit": 3, "per_query": 2},
    "balanced": {"selected": 8, "query_limit": 8, "per_query": 3},
    "quality": {"selected": 12, "query_limit": 12, "per_query": 4},
}


def _limits(mode: str) -> dict:
    base = dict(MODE_LIMITS.get(mode, MODE_LIMITS["balanced"]))
    settings = get_settings()
    base["selected"] = min(base["selected"], settings.DEEP_RESEARCH_MAX_SOURCES)
    base["query_limit"] = min(base["query_limit"], settings.DEEP_RESEARCH_MAX_QUERIES)
    return base


def rank_research_sources(topic: str, subplans: list[ResearchSubPlan], sources: list[dict], mode: str) -> list[dict]:
    seen: set[str] = set()
    ranked: list[dict] = []
    topic_words = {w.lower() for w in re.findall(r"[a-z0-9][a-z0-9_-]+", topic.lower()) if len(w) > 2}
    for source in sources:
        url = source.get("canonical_url") or source.get("url") or source.get("video_id") or source.get("title")
        if not url:
            continue
        canonical = str(url).rstrip("/").lower()
        if canonical in seen:
            continue
        seen.add(canonical)
        text = f"{source.get('title','')} {source.get('snippet','')} {source.get('description','')}".lower()
        matched = sum(1 for word in topic_words if word in text)
        relevance = float(source.get("relevance_score") or matched / max(len(topic_words), 1))
        if topic_words and matched == 0 and relevance <= 0:
            continue
        evidence = {"metadata": 0.1, "snippet": 0.25, "abstract": 0.5, "fulltext": 1.0}.get(source.get("evidence_level"), 0.1)
        quality = relevance * 0.7 + evidence * 0.3
        score = float(source.get("fusion_score") or 0) + quality
        ranked.append({**source, "canonical_url": canonical, "relevance_score": round(relevance, 6), "quality_score": round(quality, 6), "score": round(score, 6), "why": "Dipilih setelah deduplikasi, relevance gate, dan penilaian tingkat bukti."})
    ranked.sort(key=lambda item: (-float(item.get("score") or 0), str(item.get("title") or "")))
    return ranked[: _limits(mode)["selected"]]


def generate_research_brief(topic: str, subplans: list[ResearchSubPlan], sources: list[dict]) -> str:
    web_sources = [s for s in sources if s.get("source_type") != "youtube"]
    youtube_sources = [s for s in sources if s.get("source_type") == "youtube"]
    lines = [f"*Deep Research Brief: {topic}*\n"]
    lines.append("*1. Tujuan*")
    lines.append(f"Memetakan {topic} menjadi konsep, sumber belajar, risiko, dan langkah implementasi MVP.\n")
    lines.append("*2. Sub-Plan Riset*")
    for i, subplan in enumerate(subplans, 1):
        lines.append(f"{i}. {subplan.title}")
        lines.append(f"   Fokus: {subplan.question}")
    lines.append("\n*3. Temuan Utama*")
    lines.append("• Mulai dari konsep inti sebelum memilih tools.")
    lines.append("• Pisahkan research, knowledge storage, roadmap, dan approval agar aman.")
    lines.append("• Untuk Xninetzy, MVP terbaik adalah SQLite-first dan WhatsApp-first.\n")
    lines.append("*4. Ringkasan per Sub-Plan*")
    for i, subplan in enumerate(subplans, 1):
        lines.append(f"*Sub-plan {i} - {subplan.title}*")
        lines.append(f"• {subplan.expected_output}")
    lines.append("\n*5. Sumber Terpilih*")
    if web_sources:
        for source in web_sources[:8]:
            sid = source.get("sid") or ""
            prefix = f"[{sid}] " if sid else ""
            lines.append(f"{prefix}{source.get('title') or 'Untitled'}")
            if source.get("url"):
                lines.append(f"   {source['url']}")
            lines.append(f"   Kenapa penting: {source.get('why')}")
    else:
        lines.append("Belum ada sumber web karena provider search belum aktif atau tidak mengembalikan hasil.")
    lines.append("\n*6. YouTube Learning Path*")
    if youtube_sources:
        for source in youtube_sources[:6]:
            sid = source.get("sid") or ""
            prefix = f"[{sid}] " if sid else ""
            lines.append(f"{prefix}{source.get('title') or 'Video'}")
            lines.append(f"   Fokus: {source.get('description') or 'Belajar bertahap dari video ini.'}")
            if source.get("url"):
                lines.append(f"   {source['url']}")
    else:
        lines.append("Belum ada video karena YouTube API belum aktif atau tidak mengembalikan hasil.")
    lines.append("\n*7. Rekomendasi Belajar*")
    lines.append("• Mulai dari definisi dan arsitektur.")
    lines.append("• Praktikkan dengan mini project kecil.")
    lines.append("• Simpan catatan penting ke Obsidian setelah approval.\n")
    lines.append("*8. Graph RAG Draft*")
    lines.append("Node yang disarankan:")
    lines.append(f"• topic: {topic}")
    lines.append("• concept: konsep dasar, arsitektur, MVP")
    lines.append("• source: sumber web/video terpilih")
    lines.append("Edge:")
    lines.append("• topic related_to concept")
    lines.append("• research_brief references source")
    lines.append("• roadmap created_from research_brief\n")
    lines.append("*9. Next Action*")
    lines.append("Balas:")
    lines.append("• `simpan ke obsidian`")
    lines.append("• `buat roadmap`")
    lines.append("• `ingest ke knowledge`")
    lines.append("• `hubungkan ke graph`")
    if sources:
        lines.append("")
        lines.append(format_sources_block(sources))
    return "\n".join(lines)


async def _run_deep_research(
    topic: str,
    chat_id: str,
    sender_id: str | None,
    sender_name: str | None,
    chat_type: str,
    metadata: dict | None,
    mode: str = "balanced",
    include_youtube: bool = True,
    include_academic: bool = False,
) -> str:
    mode = mode if mode in MODE_LIMITS else "balanced"
    allowed, reason = can_run_deep_research(sender_id, sender_name, chat_type, metadata)
    if not allowed:
        return deep_research_denied_message(reason)

    guard_ok, guard_reason = check_resource_guards(chat_id)
    if not guard_ok:
        return resource_guard_denied_message(guard_reason)

    session_id = create_research_session(chat_id, topic, sender_id, sender_name, mode)
    await notify_admin(
        "deep_research_started",
        {"requester_name": sender_name, "topic": topic, "mode": mode, "chat_type": chat_type},
        "medium",
    )
    try:
        emit_chat_event("phase", "Planning research")
        plan_step = add_substep(session_id, "planning", "Membuat rencana riset", topic)
        plan_action = ResearchActionRegistry.get("plan")
        plan = await plan_action.execute(ResearchActionInput(session_id=session_id, topic=topic, mode=mode)) if plan_action else None
        update_substep_status(session_id, plan_step, "done", plan.data if plan else {})
        emit_chat_event("phase", "Research plan completed", "completed")

        sub_step = add_substep(session_id, "subplanning", "Memecah topik menjadi sub-plan")
        sub_action = ResearchActionRegistry.get("subplan")
        sub_result = await sub_action.execute(
            ResearchActionInput(
                session_id=session_id,
                topic=topic,
                mode=mode,
                config={"scope": (plan.data or {}).get("scope") if plan else None},
            )
        )
        subplans = [ResearchSubPlan(**item) for item in sub_result.data["subplans"]]
        set_plan(session_id, [sp.model_dump() for sp in subplans])
        update_substep_status(session_id, sub_step, "done", {"count": len(subplans)})
        await notify_admin(
            "deep_research_plan_created",
            {"topic": topic, "subplans": [sp.title for sp in subplans]},
            "medium",
        )

        all_sources: list[dict] = []
        query_count = 0
        limits = _limits(mode)
        web_action = ResearchActionRegistry.get("web_search")
        yt_action = ResearchActionRegistry.get("youtube_search")
        academic_action = ResearchActionRegistry.get("academic_search")

        for subplan in subplans:
            emit_chat_event("source", "Researching source group", detail=subplan.title)
            search_step = add_substep(session_id, "web_searching", subplan.title, payload={"queries": subplan.search_queries})
            for query in subplan.search_queries:
                if query_count >= limits["query_limit"]:
                    break
                query_count += 1
                if web_action:
                    out = await web_action.execute(
                        ResearchActionInput(
                            session_id=session_id,
                            topic=topic,
                            query=query,
                            mode=mode,
                            config={"limit": limits["per_query"]},
                        )
                    )
                    all_sources.extend(out.data.get("sources", []))
                if include_youtube and yt_action and query_count <= 3:
                    out = await yt_action.execute(
                        ResearchActionInput(
                            session_id=session_id,
                            topic=topic,
                            query=f"{query} tutorial",
                            mode=mode,
                            config={"limit": 2, "include_youtube": True},
                        )
                    )
                    all_sources.extend(out.data.get("sources", []))
                if include_academic and academic_action and query_count <= min(3, limits["query_limit"]):
                    out = await academic_action.execute(
                        ResearchActionInput(
                            session_id=session_id,
                            topic=topic,
                            query=query,
                            mode=mode,
                            config={"include_academic": True},
                        )
                    )
                    all_sources.extend(out.data.get("sources", []))
            update_substep_status(session_id, search_step, "done")
            emit_chat_event("source", "Source group completed", "completed", subplan.title)

        add_sources(session_id, all_sources)
        emit_chat_event("phase", "Ranking evidence")
        rank_step = add_substep(session_id, "source_ranking", "Ranking dan deduplikasi sumber")
        ranked = assign_sids(rank_research_sources(topic, subplans, all_sources, mode))
        update_substep_status(session_id, rank_step, "done", {"selected": len(ranked)})
        emit_chat_event("phase", "Synthesizing research brief")
        brief_step = add_substep(session_id, "brief_writing", "Menulis research brief")
        brief = generate_research_brief(topic, subplans, ranked)
        brief, removed = validate_citations(brief, ranked)
        update_substep_status(session_id, brief_step, "done", {"citations_removed": len(removed)})
        done_step = add_substep(session_id, "done", "Riset selesai")
        update_substep_status(session_id, done_step, "done")
        finish_session(session_id, brief)
        emit_chat_event("phase", "Research completed", "completed")
        await notify_admin(
            "deep_research_done",
            {
                "topic": topic,
                "subplan_count": len(subplans),
                "sources_collected": len(all_sources),
                "sources_selected": len(ranked),
            },
            "medium",
        )
        return brief
    except Exception as exc:
        emit_chat_event("phase", "Research failed", "failed")
        fail_session(session_id, str(exc))
        await notify_admin("deep_research_failed", {"topic": topic, "status": str(exc)}, "critical")
        return f"⚠️ Deep research gagal: {exc}"


async def run_deep_research(
    topic: str,
    chat_id: str,
    sender_id: str | None,
    sender_name: str | None,
    chat_type: str,
    metadata: dict | None,
    mode: str = "balanced",
    include_youtube: bool = True,
    include_academic: bool = False,
) -> str:
    timeout_seconds = get_settings().XNINETZY_DEEP_RESEARCH_TIMEOUT_SECONDS
    try:
        async with asyncio.timeout(timeout_seconds):
            return await _run_deep_research(
                topic=topic,
                chat_id=chat_id,
                sender_id=sender_id,
                sender_name=sender_name,
                chat_type=chat_type,
                metadata=metadata,
                mode=mode,
                include_youtube=include_youtube,
                include_academic=include_academic,
            )
    except TimeoutError:
        sessions = list_research_sessions(chat_id, limit=1)
        if sessions and sessions[0].get("status") != "done":
            fail_session(int(sessions[0]["id"]), "deep_research_timeout")
        emit_chat_event("phase", "Research timed out", "failed")
        return f"Deep research timed out after {timeout_seconds} seconds. Partial session progress was preserved."
